"""
Main package for the simulation project.
"""