"""Initial conditions builder."""

from .ic_builder import ICBuilder

__all__ = ['ICBuilder']
