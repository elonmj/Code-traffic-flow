"""State management."""

from .state_manager import StateManager

__all__ = ['StateManager']
