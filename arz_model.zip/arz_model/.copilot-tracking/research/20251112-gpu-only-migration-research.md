﻿<!-- markdownlint-disable-file -->
# Task Research Notes: GPU-Only Architecture Migration Strategy

## Research Executed

### File Analysis
- rchitecture_analysis.txt
  - Identified 167 dead/unused functions across the project
  - Found 13 GPU/CPU duplicate function pairs for unification
  - Discovered 64 GPU functions, 23 with dependency chains
  - Mapped sync_from_gpu/sync_to_gpu usage across 5 files

### Code Search Results
- **sync_from_gpu|sync_to_gpu|copy_to_host|to_device**
  - Found 20 CPUGPU transfer points creating overhead
  - Key transfer locations:
    * state_manager.py: sync_from_gpu(), sync_to_gpu()  
    * unner.py: cuda.to_device() for U and R arrays
    * 	ime_integration.py: copy_to_host() fallbacks
    * weno_cuda.py: bidirectional transfers in reconstruction
    * 
etwork_coupling_corrected.py: GPUCPUGPU round trips

- **device parameter cpu gpu fallback _resolve_device**
  - Device resolution logic found in unner.py:_resolve_device()
  - Multiple device checks: params.device, config.device, fallback to 'cpu'
  - GPU availability validation via cuda.is_available()
  - 15+ locations with if device == 'gpu' conditional branching

### Project Conventions
- Standards referenced: Architecture follows CPU/GPU hybrid pattern
- Current device handling: Dual-path implementations with device parameter switches
- Memory management: GPUMemoryManager class tracks allocations but underutilized

## Key Discoveries

### Project Structure - CPU/GPU Hybrid Complexity

**Current Architecture Pain Points:**
`
1. DUAL PATH MAINTENANCE (13 function pairs)
    calculate_pressure_derivative_cuda      calculate_pressure_derivative
    calculate_spatial_discretization_weno_gpu  calculate_spatial_discretization_weno
    solve_hyperbolic_step_standard_gpu     solve_hyperbolic_step_standard
    strang_splitting_step_gpu              strang_splitting_step

2. TRANSFER OVERHEAD (20+ transfer points)
    state_manager: sync_from_gpu()  sync_to_gpu() cycles
    runner: U and d_R arrays copied every step
    network_coupling: GPUCPUGPU round trips
    weno_cuda: copy_to_host() for boundary conditions

3. CONDITIONAL DEVICE BRANCHING (50+ locations)
   if device == 'gpu':
       # GPU path
   else:
       # CPU path
`

**Dead Code Burden (167 unused functions):**
- 31 GPU-related functions never called
- 47 CPU-only physics/solver functions unused
- 23 configuration/validation functions orphaned
- 15 legacy network topology functions abandoned

### Implementation Patterns

**Current GPU Workflow (Inefficient):**
`mermaid
graph LR
    A[CPU Initial State] -->|cuda.to_device| B[GPU Memory]
    B --> C{GPU Compute}
    C -->|copy_to_host| D[CPU for Coupling]
    D -->|cuda.to_device| E[Back to GPU]
    E --> F{GPU Compute}
    F -->|sync_from_gpu| G[CPU for Output]
`

**Target GPU-Only Workflow (Optimal):**
`mermaid
graph LR
    A[GPU Initial State] --> B[GPU Compute Loop]
    B --> B
    B -->|Periodic Checkpoint| C[GPUCPU for Save]
    C --> B
    B -->|Final Results| D[GPUCPU Once]
`

### Complete Examples

**Example 1: Current Strang Splitting (Hybrid - Inefficient)**
`python
# d:\Projets\Alibi\Code project\arz_model\numerics\time_integration.py:1368
def strang_splitting_step_gpu(U_gpu, dt: float, grid: Grid1D, params: ModelParameters, seg_id: str = None):
    #  PROBLEM: Transfers road quality every call
    d_R = cuda.to_device(grid.road_quality[grid.physical_cell_indices])  # <-- OVERHEAD
    
    # ODE step 1
    d_U_star = solve_ode_step_gpu(U_gpu, dt/2, grid, params, d_R)
    
    # Hyperbolic step  
    d_U_ss = solve_hyperbolic_step_ssprk3_gpu(d_U_star, dt, grid, params)
    
    # ODE step 2
    d_U_new = solve_ode_step_gpu(d_U_ss, dt/2, grid, params, d_R)
    
    return d_U_new
`

**Example 2: Network Coupling Round Trip (GPUCPUGPU - Terrible)**
`python
# d:\Projets\Alibi\Code project\arz_model\numerics\network_coupling_corrected.py:307
def apply_network_coupling_gpu_corrected(d_U, dt: float, grid: Grid1D,
                                       params: ModelParameters, nodes: List[Intersection],
                                       time: float):
    #  PROBLEM: Brings entire state to CPU for node solving
    U_cpu = d_U.copy_to_host()  # <-- HUGE OVERHEAD
    
    coupling = NetworkCouplingCorrected(nodes, params)
    U_modified = coupling.apply_network_coupling(U_cpu, dt, grid, time)
    
    d_U_modified = cuda.to_device(U_modified)  # <-- DOUBLE OVERHEAD
    return d_U_modified
`

**Example 3: State Manager Sync Cycles (Unnecessary)**
`python
# d:\Projets\Alibi\Code project\arz_model\simulation\state\state_manager.py:161
def sync_from_gpu(self):
    """Transfer state from GPU to CPU."""
    if self.device == 'gpu' and self.d_U is not None:
        self.U = cp.asnumpy(self.d_U)  #  Every output step

def sync_to_gpu(self):
    """Transfer state from CPU to GPU."""
    if self.device == 'gpu' and cp is not None:
        self.d_U = cp.asarray(self.U)  #  Why sync back?
`

### API and Schema Documentation

**Current Device Resolution API:**
`python
# d:\Projets\Alibi\Code project\arz_model\simulation\runner.py:156
@staticmethod
def _resolve_device(device_override: Optional[str], params: 'ModelParameters', quiet: bool) -> str:
    """
    Priority order:
    1. device_override argument
    2. params.device
    3. Default to 'cpu'  #  Remove this fallback for GPU-only
    """
    chosen_device = 'cpu'  #  Change default to 'gpu'
    
    if device_override:
        chosen_device = device_override.lower()
    elif hasattr(params, 'device') and params.device:
        chosen_device = params.device.lower()

    if chosen_device == 'gpu':
        if not cuda.is_available():  #  Make this raise error instead
            if not quiet:
                print(" WARNING: GPU device requested, but CUDA is not available. Falling back to CPU.")
            return 'cpu'
        return 'gpu'
    
    return 'cpu'
`

### Configuration Examples

**Current Dual-Device Config Pattern:**
`yaml
# config/builders.py - Multiple device parameters scattered
@staticmethod
def simple_corridor(
    segments: int = 2,
    segment_length: float = 200.0,
    N_per_segment: int = 40,
    device: str = 'cpu',  #  Remove this parameter entirely
    decision_interval: float = 15.0,
    t_final: float = 3600.0
) -> NetworkSimulationConfig:
`

**GPU Memory Management (Underutilized):**
`python
# d:\Projets\Alibi\Code project\arz_model\numerics\gpu\utils.py:143
class GPUMemoryManager:
    """Currently tracks allocations but doesn't prevent transfers"""
    
    def __init__(self):
        self.allocated_arrays = []  #  Keep this
        self.peak_memory = 0
        
    def allocate_device_array(self, shape, dtype=np.float64):
        #  Expand this for persistent GPU arrays
        array = cuda.device_array(shape, dtype=dtype)
        self.allocated_arrays.append(array)
        current_memory = self.get_current_memory_usage()
        self.peak_memory = max(self.peak_memory, current_memory)
        return array
`

### Technical Requirements

**GPU-Only Migration Requirements:**

1. **Eliminate All CPU Fallbacks**
   - Remove if device == 'cpu' branches (50+ locations)
   - Delete CPU-only function implementations (13 pairs)
   - Hardcode device = 'gpu' or remove parameter entirely
   - Make CUDA unavailability raise RuntimeError, not fall back

2. **Persistent GPU Memory Strategy**
   - Pre-allocate all GPU arrays at initialization (U, R, boundary states)
   - Never call copy_to_host() except for:
     * Final results export
     * Checkpoint saves (configurable interval)
     * Debugging (controlled by flag)
   - Implement GPU-native node solving (currently CPU-only)

3. **Rewrite GPU-Incomplete Functions**
   - pply_network_coupling_gpu_corrected() - needs GPU node solver
   - solve_node_fluxes() - currently CPU-only, convert to CUDA kernel
   - Boundary condition application - minimize transfers
   - WENO reconstruction - eliminate copy_to_host in boundary handling

4. **Code Cleanup Targets**
   - Delete 167 unused functions (verified via call graph)
   - Remove StateManager sync methods (sync_from_gpu, sync_to_gpu)
   - Eliminate device resolution logic (_resolve_device)
   - Clean up conditional device branching

5. **Testing & Validation**
   - GPU-only integration tests
   - Memory leak detection with GPUMemoryManager
   - Performance benchmarking vs current hybrid (expect 5-10x speedup)
   - Mass conservation validation on GPU

## Recommended Approach

### Phase 1: Pre-Migration Audit & Planning (Critical Foundation)

**Step 1.1: Comprehensive Dead Code Identification**
`ash
# Use architecture_analysis.txt findings
# Target: 167 dead functions across 25 files
# Priority: Functions with zero callers AND not entry points
`

**Categories to Delete:**
1. **Never-Called GPU Functions (31 functions)**
   - _calculate_max_wavespeed_kernel - CFL calculation unused
   - econstruct_weno5_gpu_naive/optimized - WENO wrapper functions
   - integrate_ssp_rk3_gpu - standalone integration unused
   - check_cuda_availability, alidate_gpu_vs_cpu - utility dead code

2. **CPU-Only Duplicates (13 function pairs  keep GPU, delete CPU)**
   -  Delete: calculate_pressure_derivative (CPU)
   -  Keep: calculate_pressure_derivative_cuda (GPU)
   -  Delete: strang_splitting_step (CPU)
   -  Keep: strang_splitting_step_gpu (GPU)

3. **Legacy/Abandoned Features (47 functions)**
   - main() in main_simulation.py - unused entry point
   - Network topology builders (parse_csv_to_road_network, uild_simulation_network)
   - Validation functions never called (_validate_traffic_light, _validate_node)
   - Debug/profiling utilities (profile_gpu_kernel, enchmark_weno_implementations)

**Step 1.2: Transfer Point Mapping**
Create inventory of all 20+ CPUGPU transfer locations:
`python
# TRANSFER INVENTORY (MUST ELIMINATE)
# File: simulation/state/state_manager.py
sync_from_gpu()        DELETE (keep final export only)
sync_to_gpu()          DELETE  
store_output()         REFACTOR (add GPU-native checkpoint)

# File: numerics/time_integration.py  
cuda.to_device(grid.road_quality)   CACHE at initialization
copy_to_host() for BC               GPU-native BC kernel

# File: numerics/network_coupling_corrected.py
d_U.copy_to_host()      REWRITE as GPU kernel
cuda.to_device(U_modified)  ELIMINATE round trip
`

### Phase 2: Core GPU Infrastructure Hardening

**Step 2.1: GPU Memory Manager Enhancement**
`python
# NEW: numerics/gpu/memory_pool.py
class GPUMemoryPool:
    """Persistent GPU memory pool - zero runtime allocation"""
    
    def __init__(self, max_segments: int, N_per_segment: int):
        # Pre-allocate all simulation arrays
        self.d_U_pool = {}  # segment_id  device_array
        self.d_R_pool = {}  # Cached road quality
        self.d_BC_pool = {}  # Boundary condition buffers
        
        for seg_id in segment_ids:
            N_total = N_per_segment + 2*ghost_cells
            self.d_U_pool[seg_id] = cuda.device_array((4, N_total), dtype=np.float64)
            self.d_R_pool[seg_id] = cuda.device_array(N_per_segment, dtype=np.float64)
    
    def get_segment_state(self, seg_id: str):
        """Zero-copy access to GPU arrays"""
        return self.d_U_pool[seg_id]
    
    def checkpoint_to_cpu(self, seg_id: str) -> np.ndarray:
        """ONLY method allowed to transfer GPUCPU"""
        return self.d_U_pool[seg_id].copy_to_host()
`

**Step 2.2: Eliminate Device Resolution**
`python
# DELETE: runner.py:_resolve_device()
# REPLACE WITH:
class SimulationRunner:
    def __init__(self, ...):
        # GPU-only validation
        if not cuda.is_available():
            raise RuntimeError(
                "CUDA not available. This GPU-only build requires NVIDIA GPU with CUDA support.\n"
                "Install: https://docs.nvidia.com/cuda/cuda-installation-guide-linux/"
            )
        
        self.device = 'gpu'  # Hardcoded
        print(f" GPU Detected: {cuda.get_current_device().name}")
`

**Step 2.3: GPU-Native Node Solver (Critical Blocker)**
`python
# NEW: core/node_solver_gpu.py
@cuda.jit
def solve_node_fluxes_kernel(
    d_incoming_states,   # (n_incoming, 4)
    d_outgoing_capacities,  # (n_outgoing,)
    d_traffic_light_green_mask,  # (n_outgoing,)
    d_flux_out,  # Output (n_outgoing, 4)
    alpha, rho_jam, epsilon, K_m, gamma_m, K_c, gamma_c
):
    """
    GPU kernel for network node flux solving.
    Replaces CPU-only solve_node_fluxes().
    """
    idx = cuda.grid(1)
    if idx >= d_outgoing_capacities.size:
        return
    
    # Implement Riemann solver logic on GPU
    # ... (current CPU logic in core/node_solver.py:solve_node_fluxes)

# Wrapper
def solve_node_fluxes_gpu(d_U_incoming, d_capacities, light_mask, params):
    n_outgoing = d_capacities.size
    d_flux = cuda.device_array((n_outgoing, 4), dtype=np.float64)
    
    threads = 256
    blocks = (n_outgoing + threads - 1) // threads
    
    solve_node_fluxes_kernel[blocks, threads](
        d_U_incoming, d_capacities, light_mask, d_flux,
        params.physics.alpha, params.physics.rho_jam, ...
    )
    
    return d_flux  # STAYS ON GPU
`

### Phase 3: Function Deletion & Consolidation

**Step 3.1: CPU Function Removal (13 pairs)**
`ash
# Script: scripts/delete_cpu_functions.py
CPU_GPU_PAIRS = [
    ("calculate_pressure_derivative", "calculate_pressure_derivative_cuda"),
    ("calculate_spatial_discretization_weno", "calculate_spatial_discretization_weno_gpu"),
    ("solve_hyperbolic_step_standard", "solve_hyperbolic_step_standard_gpu"),
    ("strang_splitting_step", "strang_splitting_step_gpu"),
    ("solve_ode_step_cpu", "solve_ode_step_gpu"),
    ("central_upwind_flux", "central_upwind_flux_gpu"),
    # ... 7 more pairs
]

for cpu_func, gpu_func in CPU_GPU_PAIRS:
    # 1. Find all references to cpu_func
    # 2. Replace with gpu_func
    # 3. Delete cpu_func definition
    # 4. Remove _gpu suffix (rename gpu_func  original name)
`

**Step 3.2: Dead Code Purge (167 functions)**
`python
# Priority deletion targets from architecture_analysis.txt:

# CATEGORY: GPU utilities never called (31 functions)
DELETE: numerics/gpu/utils.py
  - check_cuda_availability()
  - profile_gpu_kernel()  
  - validate_gpu_vs_cpu()
  - benchmark_weno_implementations()

DELETE: numerics/gpu/weno_cuda.py  
  - reconstruct_weno5_gpu_naive()
  - reconstruct_weno5_gpu_optimized()
  - All wrapper functions (use kernels directly)

# CATEGORY: Unused physics (47 functions)
DELETE: core/physics.py (CPU versions)
  - calculate_equilibrium_speed()
  - calculate_source_term()
  - calculate_relaxation_time()

# CATEGORY: Legacy network builders (23 functions)
DELETE: road_network/builder.py
DELETE: road_network/parser.py
DELETE: simulation/initial_conditions.py
  - riemann_problem()
  - density_hump()
  - sine_wave_perturbation()

# CATEGORY: Abandoned config validators (15 functions)
DELETE: config/network_config.py
  - _validate_network_schema()
  - _validate_traffic_light()
  - load_network_config()
`

### Phase 4: Transfer Elimination & GPU-Native Rewrites

**Step 4.1: Persistent GPU Array Initialization**
`python
# REPLACE: simulation/runner.py:_common_initialization()
def _common_initialization_gpu_only(self):
    """Initialize ALL data on GPU, never transfer"""
    
    # 1. Create GPU memory pool
    self.gpu_pool = GPUMemoryPool(
        segment_ids=list(self.network_grid.segments.keys()),
        N_per_segment=self.config.grid.N,
        ghost_cells=self.grid.num_ghost_cells
    )
    
    # 2. Initialize state directly on GPU
    for seg_id, segment in self.network_grid.segments.items():
        U0_cpu = self._create_initial_state(segment)
        d_U0 = cuda.to_device(U0_cpu)  # ONLY TRANSFER AT INITIALIZATION
        self.gpu_pool.d_U_pool[seg_id] = d_U0
        
        # Cache road quality on GPU
        R_cpu = segment.grid.road_quality
        self.gpu_pool.d_R_pool[seg_id] = cuda.to_device(R_cpu)  # ONCE
    
    # 3. Never sync back to CPU until final export
    self.U = None  # DELETE CPU state tracking
    self.d_U = None  # Managed by gpu_pool only
`

**Step 4.2: Network Coupling GPU Rewrite**
`python
# REPLACE: numerics/network_coupling_corrected.py:apply_network_coupling_gpu_corrected()
def apply_network_coupling_gpu_native(gpu_pool: GPUMemoryPool, dt: float, 
                                      grid: Grid1D, params: ModelParameters,
                                      nodes: List[Intersection], time: float):
    """Pure GPU network coupling - zero CPU transfers"""
    
    for node in nodes:
        # 1. Gather incoming states (all on GPU)
        d_incoming_states = []
        for incoming_seg in node.incoming_segments:
            d_U_seg = gpu_pool.get_segment_state(incoming_seg.id)
            # Extract boundary cells (GPU operation)
            d_boundary = d_U_seg[:, -ghost_cells-1]  # Last interior cell
            d_incoming_states.append(d_boundary)
        
        d_incoming = cuda.to_device(np.array(d_incoming_states))  # Stack on GPU
        
        # 2. Solve node fluxes ON GPU (new kernel)
        d_flux_out = solve_node_fluxes_gpu(
            d_incoming, node.get_capacities(), 
            node.get_traffic_light_state(time), params
        )
        
        # 3. Update outgoing segment boundaries (GPU operation)
        for i, outgoing_seg in enumerate(node.outgoing_segments):
            d_U_seg = gpu_pool.get_segment_state(outgoing_seg.id)
            # Update ghost cells with solved flux
            d_U_seg[:, ghost_cells] = d_flux_out[i]  # GPU assignment
    
    # NO RETURN - modified gpu_pool in-place
`

**Step 4.3: StateManager GPU-Only Refactor**
`python
# REPLACE: simulation/state/state_manager.py
class StateManagerGPUOnly:
    """Manages simulation state entirely on GPU"""
    
    def __init__(self, gpu_pool: GPUMemoryPool):
        self.gpu_pool = gpu_pool
        self.t = 0.0
        self.step_count = 0
        
        # Checkpoint buffer (rare CPU transfers)
        self.checkpoint_interval = 100  # Every 100 steps
        self.checkpoints = []  # List of (time, U_cpu) tuples
    
    def update_state(self, segment_id: str, d_U_new):
        """Update GPU state (zero-copy)"""
        self.gpu_pool.d_U_pool[segment_id] = d_U_new
    
    def advance_time(self, dt: float):
        self.t += dt
        self.step_count += 1
        
        # Conditional checkpoint
        if self.step_count % self.checkpoint_interval == 0:
            self._save_checkpoint()
    
    def _save_checkpoint(self):
        """ONLY method that transfers GPUCPU"""
        checkpoint_data = {}
        for seg_id in self.gpu_pool.d_U_pool.keys():
            U_cpu = self.gpu_pool.checkpoint_to_cpu(seg_id)
            checkpoint_data[seg_id] = U_cpu
        
        self.checkpoints.append((self.t, checkpoint_data))
    
    def get_final_results(self) -> Dict:
        """Final export (single GPUCPU transfer)"""
        results = {}
        for seg_id in self.gpu_pool.d_U_pool.keys():
            results[seg_id] = self.gpu_pool.checkpoint_to_cpu(seg_id)
        
        return {
            'final_time': self.t,
            'total_steps': self.step_count,
            'states': results,
            'checkpoints': self.checkpoints
        }
    
    # DELETE: sync_from_gpu(), sync_to_gpu(), _update_mass_tracking()
`

### Phase 5: Testing, Validation & Performance Profiling

**Step 5.1: GPU-Only Integration Tests**
`python
# NEW: tests/test_gpu_only_integration.py
import pytest
from numba import cuda

def test_gpu_required():
    """Verify GPU-only build fails gracefully without CUDA"""
    if not cuda.is_available():
        with pytest.raises(RuntimeError, match="CUDA not available"):
            runner = SimulationRunner(config)

def test_no_cpu_transfers_in_loop():
    """Verify zero CPUGPU transfers during simulation"""
    runner = SimulationRunner(config)
    
    # Hook into cuda.to_device and copy_to_host
    transfer_count = 0
    original_to_device = cuda.to_device
    original_copy_to_host = cuda.devicearray.DeviceNDArray.copy_to_host
    
    def track_to_device(*args, **kwargs):
        nonlocal transfer_count
        transfer_count += 1
        return original_to_device(*args, **kwargs)
    
    def track_copy_to_host(self):
        nonlocal transfer_count  
        transfer_count += 1
        return original_copy_to_host(self)
    
    cuda.to_device = track_to_device
    cuda.devicearray.DeviceNDArray.copy_to_host = track_copy_to_host
    
    # Run simulation
    runner.run()
    
    # Restore
    cuda.to_device = original_to_device
    cuda.devicearray.DeviceNDArray.copy_to_host = original_copy_to_host
    
    # Assert: Only 2 transfers (initial + final)
    assert transfer_count == 2, f"Expected 2 transfers, got {transfer_count}"

def test_mass_conservation_gpu():
    """Verify mass conservation on GPU (no CPU validation)"""
    runner = SimulationRunner(config)
    results = runner.run()
    
    # Compute mass on CPU from final GPU state
    U_final = results['states']['seg_0']
    total_mass = np.sum(U_final[0, :] + U_final[2, :]) * config.grid.dx
    
    # Compare to initial mass
    U_initial = runner.gpu_pool.checkpoint_to_cpu('seg_0')  
    initial_mass = np.sum(U_initial[0, :] + U_initial[2, :]) * config.grid.dx
    
    assert abs(total_mass - initial_mass) / initial_mass < 1e-10
`

**Step 5.2: Performance Benchmarking**
`python
# NEW: benchmarks/benchmark_gpu_only.py
import time
from numba import cuda

def benchmark_strang_splitting_gpu_only():
    """Measure GPU-only performance vs hybrid"""
    
    # Setup
    config = simple_corridor(segments=10, N_per_segment=400)
    runner = SimulationRunner(config)
    
    # Warm-up
    for _ in range(10):
        runner.step()
    
    # Benchmark 1000 steps
    start = time.perf_counter()
    for _ in range(1000):
        runner.step()
    cuda.synchronize()  # Ensure GPU completion
    elapsed = time.perf_counter() - start
    
    steps_per_second = 1000 / elapsed
    print(f"GPU-Only Performance: {steps_per_second:.2f} steps/s")
    
    # Expected: 5-10x faster than hybrid (no transfer overhead)
    assert steps_per_second > 100, "GPU-only should achieve >100 steps/s"

def profile_memory_usage():
    """Track GPU memory usage"""
    device = cuda.get_current_device()
    
    initial_free = device.memory.free
    
    runner = SimulationRunner(config)
    runner.run()
    
    final_free = device.memory.free
    memory_used_mb = (initial_free - final_free) / (1024**2)
    
    print(f"GPU Memory Used: {memory_used_mb:.2f} MB")
    
    # Verify no memory leaks (should be constant)
    assert memory_used_mb < 1000, "Memory leak detected"
`

### Phase 6: Documentation & Migration Guide

**Step 6.1: Update README.md**
`markdown
# ARZ Traffic Model - GPU-Only Build

##  IMPORTANT: GPU-Only Version
This repository is a **GPU-only** fork optimized for high-performance simulations.
**CUDA is required** - CPU fallback has been removed.

### Requirements
- NVIDIA GPU with CUDA Compute Capability  6.0
- CUDA Toolkit 11.x or 12.x
- Python 3.9+
- Numba 0.56+

### Installation
`ash
pip install numba>=0.56 cupy-cuda11x  # Match your CUDA version
`

### Performance Improvements
- **5-10x faster** than CPU/GPU hybrid (zero transfer overhead)
- **50% less code** (13 duplicate functions removed, 167 dead functions deleted)
- **Simplified architecture** (no device branching, persistent GPU memory)

### Migration from Hybrid Version
If migrating from the CPU/GPU hybrid version:
1. Remove all device='cpu' parameters
2. Ensure CUDA is installed and working
3. GPU unavailability now raises RuntimeError (no CPU fallback)
`

**Step 6.2: CHANGELOG.md**
`markdown
# GPU-Only Migration Changelog

## Breaking Changes
-  **REMOVED**: CPU fallback (CUDA now required)
-  **REMOVED**: Device parameter from all configs
-  **REMOVED**: 167 unused functions (see architecture_analysis.txt)
-  **REMOVED**: CPU/GPU dual implementations (13 function pairs unified)

## New Features
-  **GPU Memory Pool**: Persistent GPU arrays (zero runtime allocation)
-  **GPU-Native Node Solver**: Network coupling on GPU (no CPU round trips)
-  **Checkpoint System**: Configurable GPUCPU saves (default: every 100 steps)
-  **Performance**: 5-10x speedup from transfer elimination

## Migration Guide
### Before (Hybrid)
`python
runner = SimulationRunner(config, device='cpu')  # or 'gpu'
`

### After (GPU-Only)
`python
runner = SimulationRunner(config)  # GPU automatically detected
`

## Deleted Functions (167 total)
- sync_from_gpu(), sync_to_gpu() - replaced by checkpoint system
- _resolve_device() - GPU hardcoded
- All CPU function variants - GPU versions renamed
- See .copilot-tracking/deleted_functions.txt for full list
`

## Implementation Guidance

**Objectives:**
1. Eliminate all CPUGPU transfer overhead (20+ transfer points)
2. Delete 167 unused functions and 13 CPU duplicates
3. Implement GPU-native network coupling (currently CPU-only blocker)
4. Achieve 5-10x performance improvement

**Key Tasks:**
1. **Pre-Migration Audit**
   - Map all 20 CPUGPU transfer locations
   - Verify 167 dead functions with call graph
   - Document current device branching (50+ locations)

2. **Core Infrastructure**
   - Implement GPUMemoryPool for persistent arrays
   - Hardcode device='gpu', remove fallback logic
   - Create GPU-native node solver kernel

3. **Code Deletion**
   - Remove 13 CPU function implementations
   - Delete 167 unused functions
   - Eliminate StateManager sync methods
   - Clean up device resolution logic

4. **GPU-Native Rewrites**
   - pply_network_coupling_gpu_native() - zero transfers
   - StateManagerGPUOnly - checkpoint-based saves
   - _common_initialization_gpu_only() - persistent GPU state

5. **Testing & Validation**
   - GPU-only integration tests
   - Transfer count verification (2 per simulation)
   - Mass conservation on GPU
   - Performance benchmarking (target: >100 steps/s)

**Dependencies:**
- Numba CUDA kernel development
- GPU memory profiling tools
- Call graph analysis (already done in architecture_analysis.txt)

**Success Criteria:**
-  Zero CPUGPU transfers during simulation loop
-  5-10x performance improvement vs hybrid
-  <50% codebase size (167 functions deleted)
-  All tests passing on GPU-only build
-  Memory leak free (constant GPU usage)

## External Research References

### CUDA Best Practices (NVIDIA)
#fetch:https://docs.nvidia.com/cuda/cuda-c-best-practices-guide/index.html
- **Minimize Host-Device Transfers**: "Data transfer between host and device has much lower bandwidth than internal GPU memory access" (Section 9.1)
- **Persistent Thread Blocks**: Keep kernels running, feed work via device queues (Section 9.2.3)
- **Unified Memory Considerations**: "Unified Memory is not a performance optimization" - explicit management preferred (Section 10.1)

### Numba CUDA Programming Guide
#fetch:https://numba.readthedocs.io/en/stable/cuda/index.html
- **Device Array Management**: Use cuda.device_array() for persistent GPU arrays, avoid 	o_device() in loops
- **Kernel Launch Overhead**: Minimize kernel launches by batching operations (Section: Kernel Invocation)
- **Memory Coalescing**: Align memory access patterns for 10-100x speedup (Section: Memory Management)

### GPU-Only Application Patterns
#githubRepo:"rapidsai/cudf GPU-only dataframe patterns"
- Persistent GPU memory pools
- Zero-copy device-to-device operations  
- Lazy CPU materialization (only for final export)

#githubRepo:"cupy/cupy GPU array library architecture"
- Device memory caching strategies
- Kernel fusion to reduce transfers
- Synchronization patterns for multi-GPU

### Performance Profiling Tools
- **Nsight Systems**: Timeline analysis to detect CPUGPU transfers
- **Nsight Compute**: Kernel-level profiling for memory bottlenecks
- **CuPy/Numba Profilers**: Python-level GPU metrics
