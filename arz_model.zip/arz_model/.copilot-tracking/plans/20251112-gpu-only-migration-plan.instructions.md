﻿---
applyTo: '.copilot-tracking/changes/20251112-gpu-only-migration-changes.md'
---
<!-- markdownlint-disable-file -->
# Task Checklist: GPU-Only Architecture Migration

## Overview

Migrate ARZ traffic simulation from CPU/GPU hybrid to pure GPU-only architecture for 5-10x performance improvement by eliminating transfer overhead and removing dead code.

## Objectives

- Eliminate all CPUGPU transfer overhead (20+ transfer points)
- Delete 167 unused functions and 13 CPU/GPU duplicate pairs
- Implement GPU-native network coupling (currently CPU-only blocker)
- Achieve 5-10x performance improvement with persistent GPU memory
- Reduce codebase size by ~50% through dead code removal

## Research Summary

### Project Files
- rchitecture_analysis.txt - Identified 167 dead functions, 13 CPU/GPU pairs, 64 GPU functions
- simulation/state/state_manager.py - sync_from_gpu/sync_to_gpu overhead
- 
umerics/time_integration.py - copy_to_host() fallbacks in loops
- 
umerics/network_coupling_corrected.py - GPUCPUGPU round trips
- simulation/runner.py - Device resolution logic with CPU fallback

### External References
- #file:../research/20251112-gpu-only-migration-research.md - Complete migration strategy
- #fetch:https://docs.nvidia.com/cuda/cuda-c-best-practices-guide/index.html - Minimize host-device transfers
- #githubRepo:"rapidsai/cudf GPU-only dataframe patterns" - Persistent GPU memory pools
- #githubRepo:"cupy/cupy GPU array library architecture" - Device memory caching strategies

### Standards References
- #file:../../copilot/python.md - Python coding conventions
- #file:../.github/instructions/performance-optimization.instructions.md - Performance best practices

## Implementation Checklist

### [ ] Phase 1: Pre-Migration Audit & Dead Code Identification

- [ ] Task 1.1: Map all CPUGPU transfer points (20+ locations)
  - Details: .copilot-tracking/details/20251112-gpu-only-migration-details.md (Lines 10-50)

- [ ] Task 1.2: Verify dead function list with call graph analysis
  - Details: .copilot-tracking/details/20251112-gpu-only-migration-details.md (Lines 52-90)

- [ ] Task 1.3: Document device branching locations (50+ if statements)
  - Details: .copilot-tracking/details/20251112-gpu-only-migration-details.md (Lines 92-120)

- [ ] Task 1.4: Create deletion inventory and backup strategy
  - Details: .copilot-tracking/details/20251112-gpu-only-migration-details.md (Lines 122-150)

### [ ] Phase 2: Core GPU Infrastructure Hardening

- [ ] Task 2.1: Create GPUMemoryPool class for persistent arrays
  - Details: .copilot-tracking/details/20251112-gpu-only-migration-details.md (Lines 152-210)

- [ ] Task 2.2: Hardcode device='gpu' and remove CPU fallback
  - Details: .copilot-tracking/details/20251112-gpu-only-migration-details.md (Lines 212-250)

- [ ] Task 2.3: Implement GPU-native node solver kernel (CRITICAL)
  - Details: .copilot-tracking/details/20251112-gpu-only-migration-details.md (Lines 252-320)

- [ ] Task 2.4: Pre-allocate all GPU arrays at initialization
  - Details: .copilot-tracking/details/20251112-gpu-only-migration-details.md (Lines 322-360)

### [ ] Phase 3: Function Deletion & Consolidation

- [ ] Task 3.1: Delete 13 CPU function implementations
  - Details: .copilot-tracking/details/20251112-gpu-only-migration-details.md (Lines 362-420)

- [ ] Task 3.2: Remove 31 unused GPU utility functions
  - Details: .copilot-tracking/details/20251112-gpu-only-migration-details.md (Lines 422-460)

- [ ] Task 3.3: Delete 47 unused CPU-only physics functions
  - Details: .copilot-tracking/details/20251112-gpu-only-migration-details.md (Lines 462-500)

- [ ] Task 3.4: Remove 23 legacy network builder functions
  - Details: .copilot-tracking/details/20251112-gpu-only-migration-details.md (Lines 502-540)

- [ ] Task 3.5: Delete 15 abandoned config validators
  - Details: .copilot-tracking/details/20251112-gpu-only-migration-details.md (Lines 542-580)

- [ ] Task 3.6: Clean up 51 miscellaneous dead functions
  - Details: .copilot-tracking/details/20251112-gpu-only-migration-details.md (Lines 582-620)

### [ ] Phase 4: Transfer Elimination & GPU-Native Rewrites

- [ ] Task 4.1: Rewrite StateManager to GPU-only with checkpoints
  - Details: .copilot-tracking/details/20251112-gpu-only-migration-details.md (Lines 622-680)

- [ ] Task 4.2: Implement GPU-native network coupling (zero transfers)
  - Details: .copilot-tracking/details/20251112-gpu-only-migration-details.md (Lines 682-740)

- [ ] Task 4.3: Cache road quality arrays on GPU at initialization
  - Details: .copilot-tracking/details/20251112-gpu-only-migration-details.md (Lines 742-770)

- [ ] Task 4.4: Eliminate WENO boundary condition transfers
  - Details: .copilot-tracking/details/20251112-gpu-only-migration-details.md (Lines 772-810)

- [ ] Task 4.5: Remove all sync_from_gpu/sync_to_gpu calls
  - Details: .copilot-tracking/details/20251112-gpu-only-migration-details.md (Lines 812-840)

### [ ] Phase 5: Testing, Validation & Performance Profiling

- [ ] Task 5.1: Create GPU-only integration tests
  - Details: .copilot-tracking/details/20251112-gpu-only-migration-details.md (Lines 842-900)

- [ ] Task 5.2: Implement transfer count verification test
  - Details: .copilot-tracking/details/20251112-gpu-only-migration-details.md (Lines 902-940)

- [ ] Task 5.3: Add mass conservation validation on GPU
  - Details: .copilot-tracking/details/20251112-gpu-only-migration-details.md (Lines 942-980)

- [ ] Task 5.4: Performance benchmark (target: 5-10x speedup)
  - Details: .copilot-tracking/details/20251112-gpu-only-migration-details.md (Lines 982-1020)

- [ ] Task 5.5: Memory leak detection and profiling
  - Details: .copilot-tracking/details/20251112-gpu-only-migration-details.md (Lines 1022-1060)

### [ ] Phase 6: Documentation & Migration Guide

- [ ] Task 6.1: Update README.md with GPU-only requirements
  - Details: .copilot-tracking/details/20251112-gpu-only-migration-details.md (Lines 1062-1100)

- [ ] Task 6.2: Create CHANGELOG.md with breaking changes
  - Details: .copilot-tracking/details/20251112-gpu-only-migration-details.md (Lines 1102-1140)

- [ ] Task 6.3: Document deleted functions list
  - Details: .copilot-tracking/details/20251112-gpu-only-migration-details.md (Lines 1142-1170)

- [ ] Task 6.4: Update installation and setup guides
  - Details: .copilot-tracking/details/20251112-gpu-only-migration-details.md (Lines 1172-1200)

## Dependencies

- Numba CUDA 0.56+ for GPU kernel development
- NVIDIA GPU with CUDA Compute Capability  6.0
- CUDA Toolkit 11.x or 12.x
- Call graph analysis (completed in architecture_analysis.txt)
- GPU memory profiling tools (Nsight Systems/Compute)

## Success Criteria

-  Zero CPUGPU transfers during simulation loop (except initialization + final export)
-  5-10x performance improvement vs current hybrid implementation
-  Codebase reduced by ~50% (167 functions deleted)
-  All integration tests passing on GPU-only build
-  Memory leak free (constant GPU usage throughout simulation)
-  Mass conservation validated on GPU (error < 1e-10)
