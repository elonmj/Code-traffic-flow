"""
Grid utilities for spatial discretization.
"""
from .grid1d import *
__all__ = ['grid1d']
# code/grid/__init__.py